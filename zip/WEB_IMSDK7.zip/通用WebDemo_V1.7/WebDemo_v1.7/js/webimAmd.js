require(['../sdk/webim'], function(webim) {
	// webim.cs();
	// //检查是否登录
	// webim.checkLogin(cbErr, isNeedCallBack);
	// //获取下载地址
	// webim.onDownFile();
	// //获取下载地址
	// webim.applyDownload();
	// //获取长轮询ID
	// webim.getLongPollingId();
	// //设置jsonp返回的值
	// webim.setJsonpLastRspData(options, cbOk, cbErr);
	// //上传图片或文件(Base64)接口
	// // webim.uploadFileByBase64();
	// // webim.uploadPicByBase64();
	// // //上传文件接口（高版本浏览器）
	// // webim.uploadFile();
	// // webim.uploadPic();
	// //提交上传图片表单接口（用于低版本ie）
	// //webim.submitUploadFileForm();
	// //拉黑
	// webim.addBlackList(options, cbOk, cbErr);
	// //删除黑名单
	// webim.deleteBlackList(options, cbOk, cbErr);
	// //获取我的黑名单
	// webim.getBlackList(options, cbOk, cbErr);
	// //获取最近会话
	// webim.getRecentContactList(options, cbOk, cbErr);


});